var files =
[
    [ "ledModule.c", "led_module_8c.html", "led_module_8c" ],
    [ "ledModule.h", "led_module_8h.html", "led_module_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "SerialLCDModule.c", "_serial_l_c_d_module_8c.html", "_serial_l_c_d_module_8c" ],
    [ "SerialLCDModule.h", "_serial_l_c_d_module_8h.html", "_serial_l_c_d_module_8h" ],
    [ "thermalSensor.c", "thermal_sensor_8c.html", "thermal_sensor_8c" ],
    [ "thermalSensor.h", "thermal_sensor_8h.html", "thermal_sensor_8h" ]
];