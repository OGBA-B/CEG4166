var main_8c =
[
    [ "main", "main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "TaskReadTemperature", "main_8c.html#a893cdfbf1eaee85a810fe15109326f0c", null ],
    [ "vApplicationStackOverflowHook", "main_8c.html#a2e0defe473604c1bd4c5a11aed724078", null ],
    [ "usartfd", "main_8c.html#ac77728f253c55ea9156a03df49e2186c", null ]
];