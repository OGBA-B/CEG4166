var thermal_sensor_8h =
[
    [ "TaskReadTemperature", "thermal_sensor_8h.html#a893cdfbf1eaee85a810fe15109326f0c", null ],
    [ "avgTemp", "thermal_sensor_8h.html#ae2fc39671c0173304986f05dba26bbbf", null ],
    [ "temps", "thermal_sensor_8h.html#a303bfbfba8466a335e14331344e03ed7", null ]
];