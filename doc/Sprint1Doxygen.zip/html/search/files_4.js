var searchData=
[
  ['thermalsensor_2ec',['thermalSensor.c',['../thermal_sensor_8c.html',1,'']]],
  ['thermalsensor_2eh',['thermalSensor.h',['../thermal_sensor_8h.html',1,'']]]
];
