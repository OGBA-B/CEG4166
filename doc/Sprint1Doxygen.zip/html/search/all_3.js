var searchData=
[
  ['extendedcommand',['extendedCommand',['../_serial_l_c_d_module_8c.html#a5ec24d8f856d89706706c77fa1d0f043',1,'extendedCommand(int8_t command):&#160;SerialLCDModule.c'],['../_serial_l_c_d_module_8h.html#a5ec24d8f856d89706706c77fa1d0f043',1,'extendedCommand(int8_t command):&#160;SerialLCDModule.c']]]
];
