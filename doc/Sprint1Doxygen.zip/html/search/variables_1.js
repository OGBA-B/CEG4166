var searchData=
[
  ['temps',['temps',['../thermal_sensor_8c.html#a303bfbfba8466a335e14331344e03ed7',1,'temps():&#160;thermalSensor.c'],['../thermal_sensor_8h.html#a303bfbfba8466a335e14331344e03ed7',1,'temps():&#160;thermalSensor.c']]],
  ['thisusartid',['thisUsartID',['../_serial_l_c_d_module_8c.html#a999d6e28f3a709a37f9336ba9ded2f6d',1,'SerialLCDModule.c']]]
];
