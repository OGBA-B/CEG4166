var searchData=
[
  ['displaytemperature',['displayTemperature',['../_serial_l_c_d_module_8c.html#a37e48baadc2b4aa993c676a6e5d29f05',1,'displayTemperature(uint8_t temps[9]):&#160;SerialLCDModule.c'],['../_serial_l_c_d_module_8h.html#a37e48baadc2b4aa993c676a6e5d29f05',1,'displayTemperature(uint8_t temps[9]):&#160;SerialLCDModule.c']]]
];
