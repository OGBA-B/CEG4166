var searchData=
[
  ['changeledcolour',['changeLEDColour',['../led_module_8c.html#a3ae9a465326d82177b3063e125e8760e',1,'changeLEDColour(uint8_t avgTemp):&#160;ledModule.c'],['../led_module_8h.html#a3ae9a465326d82177b3063e125e8760e',1,'changeLEDColour(uint8_t avgTemp):&#160;ledModule.c']]]
];
