var searchData=
[
  ['taskreadtemperature',['TaskReadTemperature',['../main_8c.html#a893cdfbf1eaee85a810fe15109326f0c',1,'TaskReadTemperature():&#160;thermalSensor.c'],['../thermal_sensor_8c.html#a893cdfbf1eaee85a810fe15109326f0c',1,'TaskReadTemperature():&#160;thermalSensor.c'],['../thermal_sensor_8h.html#a893cdfbf1eaee85a810fe15109326f0c',1,'TaskReadTemperature():&#160;thermalSensor.c']]]
];
