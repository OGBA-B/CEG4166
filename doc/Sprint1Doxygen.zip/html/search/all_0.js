var searchData=
[
  ['avgtemp',['avgTemp',['../thermal_sensor_8c.html#ae2fc39671c0173304986f05dba26bbbf',1,'avgTemp():&#160;thermalSensor.c'],['../thermal_sensor_8h.html#ae2fc39671c0173304986f05dba26bbbf',1,'avgTemp():&#160;thermalSensor.c']]]
];
